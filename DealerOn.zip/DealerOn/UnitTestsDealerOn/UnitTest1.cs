using Microsoft.VisualStudio.TestTools.UnitTesting;

using System;
using System.Collections;
using System.Collections.Generic;
using UnitTestsDealerOn;
using DealerOn;

namespace UnitTestsDealerOn
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod_Usecase1()
        {
            ArrayList itemList = new ArrayList();
            itemList.Add("1 Imported box of perfume at 27.99");
            itemList.Add("1 Bottle of perfume at 18.99");
            itemList.Add("1 Packet of headache pills at 9.75");
            itemList.Add("1 Imported box of chocolates at 11.25");
            itemList.Add("1 Imported box of chocolates at 11.25");

            Program pr = new Program();
            pr.printBill(itemList);
        }
        [TestMethod]
        public void TestMethod_Usecase2()
        {
            ArrayList itemList = new ArrayList();
            itemList.Add("1 Book at 12.49");
            itemList.Add("1 Book at 12.49");
            itemList.Add("1 Music CD at 14.99");
            itemList.Add("1 Chocolate bar at 0.85");
            Program pr = new Program();
            pr.printBill(itemList);


        }
        [TestMethod]
        public void TestMethod_Usecase3()
        {
            ArrayList itemList = new ArrayList();
            itemList.Add("1 Imported Box of chocolates at 10.00");
            itemList.Add("1 Imported bottle of perfume at 47.50");
            Program pr = new Program();
            pr.printBill(itemList);


        }
    }
}
