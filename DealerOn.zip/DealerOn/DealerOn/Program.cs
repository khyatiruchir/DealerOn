﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace DealerOn
{
   public class Program
    {
        String[] food = { "chocolate bar", "juice", "granola bar", "biscuits", "cereals","chocolates","chocolate" }; // List of Items Assuming the products . added few more items apart example 
        String[] medicine = { "headache pills", "pills", "injections","medicines" }; // List of Items of a particular type same as above
      
        static void Main(string[] args)
        {
            ArrayList items = new ArrayList();
            String userBillInput; // String to fetch the User Statement input
            //int quantity = 0;
            //float price,totalBill = 0, salesTax = 0,totalSalesTax=0;
            IDictionary< String,float> itemPrice = new Dictionary< String,float>();
            IDictionary<String, int> itemQuantity = new Dictionary<String, int>();
            //Take input from user
            Program pr = new Program();
            // Loop to read all the Input Items and process the Bill
            while (true)
            {
                userBillInput = Console.ReadLine();
                if (!string.IsNullOrEmpty(userBillInput))
                    items.Add(userBillInput);
                else
                    break;
            }

            pr.printBill(items);

        }

        /**
         * below method analyse items in arraylist and store it in dicitonary
         * it calculates tax for each item and print bill
         * this method can also be decleared in seprate class but kept here for readability purpose
         */
        public void printBill(ArrayList items)
        {
            int quantity = 0;
            float price,totalBill = 0, salesTax = 0,totalSalesTax=0;
            IDictionary<String, float> itemPrice = new Dictionary<String, float>();
            IDictionary<String, int> itemQuantity = new Dictionary<String, int>();
            foreach (var item in items)
            {
                String st = item.ToString().Trim();
                quantity = Convert.ToInt32(st.Substring(0, 1));
                //string between at and space is item name
                int positionAt = st.LastIndexOf("at");
                int positionPrice = st.LastIndexOf(" ");
                String itemName = st.Substring(1, positionAt - 1);
                price = (float)Convert.ToDouble(st.Substring(positionPrice + 1));
                //if item name is not in dictionary then add
                if (!itemPrice.ContainsKey(itemName))
                {
                    itemPrice.Add(itemName, price);
                    itemQuantity.Add(itemName, quantity);

                }
                else
                {
                    int updateQuantity = itemQuantity[itemName];
                    itemQuantity[itemName] = ++updateQuantity;

                }
                Program pr = new Program();
                salesTax = pr.CalculateTax(price, itemName.ToLower().Trim());
                totalSalesTax += salesTax;
                price = price + salesTax;
                if (salesTax != 0)
                    itemPrice[itemName] = price;
                totalBill = totalBill + price;

            }
            //print bill items
            foreach (var itemName in itemPrice)
            {
                String name = itemName.Key;
                float priceItem = (float)Math.Round(itemName.Value, 2);
                int count = itemQuantity[name];
                float finalPrice = priceItem * count;
                if (count == 1)
                    Console.WriteLine(name + ": " + priceItem);
                else
                    Console.WriteLine(name + ": " + finalPrice + " ( " + count + " @ " + priceItem + " ) ");

            }
            Console.WriteLine("Sales Taxes: " + Math.Round(totalSalesTax, 2));
            Console.WriteLine("Total: " + Math.Round(totalBill, 2));

        }
        //this method calculates tax for each item
        public float CalculateTax(float price, String itemName)
        {
            double tax = 0;
            int positionOf = itemName.LastIndexOf("of");
            int positionAt = itemName.LastIndexOf("at");
            String iteminstring = itemName.Substring(positionOf + 3);
            //no tax for food, medicine and book
            if ((Array.Exists(food,element => element == itemName))|| (Array.Exists(medicine, element => element == iteminstring))|| (itemName.Contains("book")))
            {
                tax = 0;
            }
           //if item is imported
            else if (itemName.Contains("imported"))
            {
                tax = tax + price * (float)0.05;
                if(!(Array.Exists(food, element => element == iteminstring)|| Array.Exists(medicine, element => element == itemName) || itemName.Contains("book")))
                {
                    tax = tax + price * (float)0.1;
                }
            }
            else
            {
                tax = price * (float)0.1;
            }

           //to calculate tax up to 2 digits 
            var ceiling = Math.Ceiling(tax * 20);
            return (float)ceiling / 20;
        }
    }
}
